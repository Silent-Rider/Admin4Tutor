--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4 (Ubuntu 16.4-0ubuntu0.24.04.2)
-- Dumped by pg_dump version 16.4 (Ubuntu 16.4-0ubuntu0.24.04.2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE application;
--
-- Name: application; Type: DATABASE; Schema: -; Owner: silent_rider
--

CREATE DATABASE application WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE application OWNER TO silent_rider;

\connect application

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: year_salary(integer); Type: FUNCTION; Schema: public; Owner: silent_rider
--

CREATE FUNCTION public.year_salary(salary integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE result INT := 0;
BEGIN
FOR i IN 1..12 LOOP
result := result + salary;
END LOOP;
RETURN result;
END;
$$;


ALTER FUNCTION public.year_salary(salary integer) OWNER TO silent_rider;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: silent_rider
--

CREATE TABLE public.employee (
    id integer NOT NULL,
    name character varying(50),
    occupation character varying(50),
    salary integer,
    age smallint,
    join_date date,
    exp boolean,
    hobby character varying(100)
);


ALTER TABLE public.employee OWNER TO silent_rider;

--
-- Name: employee_id_seq; Type: SEQUENCE; Schema: public; Owner: silent_rider
--

CREATE SEQUENCE public.employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employee_id_seq OWNER TO silent_rider;

--
-- Name: employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: silent_rider
--

ALTER SEQUENCE public.employee_id_seq OWNED BY public.employee.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: silent_rider
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    employee_id smallint,
    name character varying(100),
    deadline date
);


ALTER TABLE public.tasks OWNER TO silent_rider;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: silent_rider
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO silent_rider;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: silent_rider
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: employee id; Type: DEFAULT; Schema: public; Owner: silent_rider
--

ALTER TABLE ONLY public.employee ALTER COLUMN id SET DEFAULT nextval('public.employee_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: silent_rider
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: silent_rider
--

COPY public.employee (id, name, occupation, salary, age, join_date, exp, hobby) FROM stdin;
\.
COPY public.employee (id, name, occupation, salary, age, join_date, exp, hobby) FROM '$$PATH$$/3403.dat';

--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: silent_rider
--

COPY public.tasks (id, employee_id, name, deadline) FROM stdin;
\.
COPY public.tasks (id, employee_id, name, deadline) FROM '$$PATH$$/3405.dat';

--
-- Name: employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: silent_rider
--

SELECT pg_catalog.setval('public.employee_id_seq', 16, true);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: silent_rider
--

SELECT pg_catalog.setval('public.tasks_id_seq', 14, true);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: silent_rider
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: silent_rider
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

